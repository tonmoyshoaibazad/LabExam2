<?php
	if(isset($_POST['submit'])){
		$name = $_POST['name'];
		$email = $_POST['email'];
		$userName = $_POST['userName'];
		$password = $_POST['password'];
		$confirmPassword = $_POST['confirmPassword'];
		$gender = $_POST['gender'];
		
		if(empty($name)){
			echo "name is required";
		}

		/*$con = mysql_connect("localhost", "root", "");
		if(!$con){
			die ("Can't Connect to the database: ". mysql_error());
		}
		if(mysql_query("CREATE DATABASE registration", $con)){
			echo "succesfully created";
		}*/
	}



?>